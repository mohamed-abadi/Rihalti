package com.rahla90.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var pendingBackup: String? = null

    inner class BackupBridge {
        @JavascriptInterface fun saveBackup(json: String) {
            pendingBackup = json
            runOnUiThread {
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "rahla90-backup.json")
                }
                startActivityForResult(intent, 2001)
            }
        }
        @JavascriptInterface fun pickBackup() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                }
                startActivityForResult(intent, 2002)
            }
        }
    }

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(14, 79, 134)
        window.navigationBarColor = android.graphics.Color.rgb(14, 79, 134)
        webView = WebView(this)
        webView.setBackgroundColor(android.graphics.Color.rgb(243, 247, 251))
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            allowFileAccess = true
            allowContentAccess = true
            builtInZoomControls = false
            displayZoomControls = false
        }
        webView.addJavascriptInterface(BackupBridge(), "AndroidBridge")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        super.onActivityResult(requestCode, resultCode, resultData)
        if (resultCode != RESULT_OK || resultData?.data == null) return
        val uri: Uri = resultData.data!!
        try {
            when (requestCode) {
                2001 -> {
                    contentResolver.openOutputStream(uri)?.use { it.write((pendingBackup ?: "{}").toByteArray(Charsets.UTF_8)) }
                    pendingBackup = null
                    Toast.makeText(this, "تم حفظ النسخة الاحتياطية", Toast.LENGTH_SHORT).show()
                }
                2002 -> {
                    val json = contentResolver.openInputStream(uri)?.bufferedReader()?.use(BufferedReader::readText) ?: "{}"
                    val quoted = org.json.JSONObject.quote(json)
                    webView.evaluateJavascript("window.importBackupText($quoted)", null)
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر التعامل مع ملف النسخة الاحتياطية", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
